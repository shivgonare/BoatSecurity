// Movie.java
package com.example.moviebookingsystem.model;

import javax.persistence.*;
import java.util.List;

@Entity
public class Movie {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String title;
    private String genre;
    private String showtimes;

    // Getters and setters
}