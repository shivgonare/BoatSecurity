// BookingRepository.java
package com.example.moviebookingsystem.repository;

import com.example.moviebookingsystem.model.Booking;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookingRepository extends JpaRepository<Booking, Long> {
}