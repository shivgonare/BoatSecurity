// Booking.java
package com.example.moviebookingsystem.model;

import javax.persistence.*;
import java.util.Set;

@Entity
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @ManyToOne
    private User user;
    
    @ManyToOne
    private Movie movie;

    @ManyToMany
    private Set<Seat> seats;
    
    private String showtime;
    private double totalPrice;

    // Getters and setters
}