// BookingController.java
package com.example.moviebookingsystem.controller;

import com.example.moviebookingsystem.model.Booking;
import com.example.moviebookingsystem.model.Movie;
import com.example.moviebookingsystem.model.Seat;
import com.example.moviebookingsystem.service.BookingService;
import com.example.moviebookingsystem.service.MovieService;
import com.example.moviebookingsystem.service.SeatService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class BookingController {

    @Autowired
    private BookingService bookingService;

    @Autowired
    private MovieService movieService;

    @Autowired
    private SeatService seatService;

    @GetMapping("/movies")
    public String listMovies(Model model) {
        List<Movie> movies = movieService.getAllMovies();
        model.addAttribute("movies", movies);
        return "booking/selectSeats";
    }

    @PostMapping("/book")
    public String bookTickets(@ModelAttribute Booking booking, Model model) {
        bookingService.createBooking(booking);
        model.addAttribute("message", "Booking successful!");
        return "booking/confirmation";
    }

    // Additional methods for seat selection, payment, etc.
}

