// SeatRepository.java
package com.example.moviebookingsystem.repository;

import com.example.moviebookingsystem.model.Seat;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SeatRepository extends JpaRepository<Seat, Long> {
}