// MovieRepository.java
package com.example.moviebookingsystem.repository;

import com.example.moviebookingsystem.model.Movie;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MovieRepository extends JpaRepository<Movie, Long> {
}