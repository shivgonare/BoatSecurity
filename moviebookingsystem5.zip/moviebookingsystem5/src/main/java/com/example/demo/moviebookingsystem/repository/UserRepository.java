// UserRepository.java
package com.example.moviebookingsystem.repository;

import com.example.moviebookingsystem.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {
    User findByEmail(String email);
}