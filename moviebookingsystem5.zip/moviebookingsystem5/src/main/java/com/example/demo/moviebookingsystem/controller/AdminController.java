// AdminController.java
package com.example.moviebookingsystem.controller;

import com.example.moviebookingsystem.model.Movie;
import com.example.moviebookingsystem.model.Seat;
import com.example.moviebookingsystem.service.MovieService;
import com.example.moviebookingsystem.service.SeatService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private MovieService movieService;

    @Autowired
    private SeatService seatService;

    @GetMapping("/dashboard")
    public String showAdminDashboard() {
        return "admin/index";
    }

    @GetMapping("/movies")
    public String manageMovies(Model model) {
        List<Movie> movies = movieService.getAllMovies();
        model.addAttribute("movies", movies);
        return "admin/manageMovies";
    }

    @PostMapping("/movies")
    public String addMovie(@ModelAttribute Movie movie, Model model) {
        movieService.addMovie(movie);
        return "redirect:/admin/movies";
    }

    @GetMapping("/seats")
    public String manageSeats(Model model) {
        List<Seat> seats = seatService.getAllSeats();
        model.addAttribute("seats", seats);
        return "admin/manageSeats";
    }

    @PostMapping("/seats")
    public String addSeat(@ModelAttribute Seat seat, Model model) {
        seatService.addSeat(seat);
        return "redirect:/admin/seats";
    }

    // Additional methods for managing bookings, food menu, etc.
}