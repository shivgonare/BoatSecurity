// UserController.java
package com.example.moviebookingsystem.controller;

import com.example.moviebookingsystem.model.User;
import com.example.moviebookingsystem.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        model.addAttribute("user", new User());
        return "user/register";
    }

    @PostMapping("/register")
    public String registerUser(@ModelAttribute User user, Model model) {
        userService.registerUser(user);
        model.addAttribute("message", "User registered successfully!");
        return "user/login";
    }

    @GetMapping("/login")
    public String showLoginForm() {
        return "user/login";
    }

    // Additional methods for login, profile, etc.
}